﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TransportationProject
{
    public interface Transportation
    {
        void transport();
    }
    class roadway : Transportation
    {
        String[] vehicleType=new string[100];
        String pickupPoint, destination;
        Double cost;
        public void transport()
        {
            Console.Write("\nEnter the total number of vehicle:\t");
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                Console.Write("\nEnter the vehicle name:\t");
                vehicleType[i] = Console.ReadLine();
            }
            Console.Write("\nEnter the pickup point:\t");
            pickupPoint = Console.ReadLine();
            Console.Write("\nEnter the destination point:\t");
            destination = Console.ReadLine();
            Console.Write("\nEnter the cost for transportation:\t");
            cost = Double.Parse(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("-------------------ROADWAY TRANSPORTATION-----------------------");
            Console.WriteLine("List of vehicle type:\n");
            for (int i=0; i < n;i++)
          
            {
                Console.WriteLine(vehicleType[i]);
            }
            Console.WriteLine($"Pickup point : {pickupPoint}");
            Console.WriteLine($"Destination  : {destination}");
            Console.WriteLine($"Cost         : {cost}");
        }
        class seaWay : Transportation
        {
            String pickupPoint, destination, harborPickupName, destinationHarbor;
            Double cost;
            public void transport()
            {
                Console.Write("\nEnter the pickup point:\t");
                pickupPoint = Console.ReadLine();
                Console.Write("\nEnter the destination point:\t");
                destination = Console.ReadLine();
                Console.Write("\nEnter the cost for transportation:\t");
                cost = Double.Parse(Console.ReadLine());
                Console.Write("\nEnter the harbor pickup pointt:\t");
                harborPickupName = Console.ReadLine();
                Console.Write("\nEnter the harbor destination point:\t");
                destinationHarbor = Console.ReadLine();
                Console.Clear();
                Console.WriteLine("-------------SEA WAY TRANSPORTATION----------------");
                Console.WriteLine($"Pickup Point        :           {pickupPoint}");
                Console.WriteLine($"Destination Point   :           {destination}");
                Console.WriteLine($"Pickup Harbor Point :           {harborPickupName}");
                Console.WriteLine($"Destination Harbor  Point :     {destinationHarbor}");
                Console.WriteLine($"Cost :                          {cost}");
            }
        }
        class airWay : Transportation
        {
            String pickupPoint, destination,airpostPickup, airportDestination;
            Double cost;
            public void transport()
            {
                Console.Write("\nEnter the pickup point:\t");
                pickupPoint = Console.ReadLine();
                Console.Write("\nEnter the destination point:\t");
                destination = Console.ReadLine();
                Console.Write("\nEnter the cost for transportation:\t");
                cost = Double.Parse(Console.ReadLine());
                Console.Write("\nEnter the airport name for pickup:\t");
                airpostPickup = Console.ReadLine();
                Console.Write("\nEnter the destination airport:\t");
                airportDestination = Console.ReadLine();
                Console.Clear();
                Console.WriteLine("--------AIR WAY TRANSPORTATION------------");
                Console.WriteLine($"Pickup Point        :           {pickupPoint}");
                Console.WriteLine($"Destination Point   :           {destination}");
                Console.WriteLine($"Pickup Airport      :           {airpostPickup}");
                Console.WriteLine($"Destination airport :           {airportDestination}");
                Console.WriteLine($"Cost :                          {cost}");
            }
        }
        class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("Roadway Transportation");
                roadway rd = new roadway();
                rd.transport();
                Console.WriteLine("Seaway Transportation");
                seaWay s = new seaWay();
                s.transport();
                airWay r = new airWay();
                r.transport();
                Console.ReadLine();
            }
        }
    }
}
